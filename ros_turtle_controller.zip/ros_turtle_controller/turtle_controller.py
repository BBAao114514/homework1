#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import rospy
import math
from geometry_msgs.msg import Twist
from turtlesim.msg import Pose
from std_srvs.srv import Empty
from std_srvs.srv import EmptyResponse
from turtlesim.srv import TeleportAbsolute
from std_msgs.msg import Float32MultiArray
from std_srvs.srv import Trigger, TriggerResponse

class TurtleController:
    def __init__(self):
        rospy.init_node('turtle_controller', anonymous=True)

        self.velocity_publisher = rospy.Publisher('/turtle1/cmd_vel', Twist, queue_size=10)
        self.pose_subscriber = rospy.Subscriber('/turtle1/pose', Pose, self.pose_callback)

        self.current_pose = Pose()
        self.pose_received = False

        self.target_queue = []
        self.target_x = 5.0
        self.target_y = 5.0
        self.reached_callback = False

        # 控制参数
        self.distance_tolerance = 0.1
        self.angle_tolerance = 0.1
        self.linear_speed_gain = 1.5
        self.angular_speed_gain = 4.0
        self.max_linear_speed = 2.0
        self.max_angular_speed = 2.0

        # 服务：添加目标点
        rospy.Service('/set_target', Trigger, self.handle_set_target)
        rospy.Service('/reset_turtle', Empty, self.reset_turtle)

        # Teleport服务客户端
        self.teleport_service = rospy.ServiceProxy('/turtle1/teleport_absolute', TeleportAbsolute)

        rospy.loginfo("Turtle Controller initialized.")

    def pose_callback(self, msg):
        self.current_pose = msg
        self.pose_received = True

    def calculate_distance(self, x1, y1, x2, y2):
        return math.hypot(x2 - x1, y2 - y1)

    def calculate_angle_to_target(self):
        dx = self.target_x - self.current_pose.x
        dy = self.target_y - self.current_pose.y
        return math.atan2(dy, dx)

    def normalize_angle(self, angle):
        return math.atan2(math.sin(angle), math.cos(angle))

    def saturate(self, value, max_value):
        return max(-max_value, min(value, max_value))

    def stop_turtle(self):
        self.velocity_publisher.publish(Twist())

    def reset_turtle(self, req):
        try:
            rospy.wait_for_service('/turtle1/teleport_absolute')
            self.teleport_service(5.5, 5.5, 0.0)
            self.stop_turtle()
            rospy.loginfo("Turtle reset to (5.5, 5.5)")
        except rospy.ServiceException as e:
            rospy.logerr(f"Teleport service failed: {e}")
        return EmptyResponse()

    def handle_set_target(self, req):
        """服务接口示例：手动设置目标点（这里模拟为切换目标）"""
        # 示例：使用一个新点
        self.target_x = float(input("输入目标X坐标："))
        self.target_y = float(input("输入目标Y坐标："))
        rospy.loginfo(f"新目标已设定: ({self.target_x}, {self.target_y})")
        return TriggerResponse(success=True, message="目标已更新")

    def move_to_target(self):
        rate = rospy.Rate(10)

        while not rospy.is_shutdown():
            # 守护机制：异常偏移检测
            if self.current_pose.x < 0.5 or self.current_pose.x > 10.5 or self.current_pose.y < 0.5 or self.current_pose.y > 10.5:
                rospy.logwarn("检测到位置异常，执行自动复位")
                self.reset_turtle(None)
                rospy.sleep(1.0)

            distance = self.calculate_distance(
                self.current_pose.x, self.current_pose.y,
                self.target_x, self.target_y
            )

            if distance < self.distance_tolerance:
                rospy.loginfo("✅ 已到达目标点")
                self.stop_turtle()

                # 若有下一个目标点，则继续
                if self.target_queue:
                    self.target_x, self.target_y = self.target_queue.pop(0)
                    rospy.loginfo(f"切换到下一个目标: ({self.target_x}, {self.target_y})")
                else:
                    break

            target_angle = self.calculate_angle_to_target()
            angle_diff = self.normalize_angle(target_angle - self.current_pose.theta)

            vel_msg = Twist()
            if abs(angle_diff) > self.angle_tolerance:
                vel_msg.angular.z = self.saturate(self.angular_speed_gain * angle_diff, self.max_angular_speed)
            else:
                vel_msg.linear.x = self.saturate(self.linear_speed_gain * distance, self.max_linear_speed)

            self.velocity_publisher.publish(vel_msg)
            rospy.loginfo(f"[当前位置] ({self.current_pose.x:.2f}, {self.current_pose.y:.2f}) "
                          f"[距离] {distance:.2f} [角度差] {angle_diff:.2f}")

            rate.sleep()

    def load_path(self, point_list):
        """加载一个路径点序列"""
        self.target_queue = point_list
        if self.target_queue:
            self.target_x, self.target_y = self.target_queue.pop(0)
            rospy.loginfo(f"加载路径，起始目标: ({self.target_x}, {self.target_y})")

if __name__ == '__main__':
    try:
        controller = TurtleController()

        # 等待pose更新
        while not controller.pose_received and not rospy.is_shutdown():
            rospy.sleep(0.1)

        # 设置路径点序列（可拓展成外部加载）
        path = [(2.0, 2.0), (8.0, 2.0), (8.0, 8.0), (2.0, 8.0), (5.5, 5.5)]
        controller.load_path(path)

        rospy.loginfo(f"起始位置: ({controller.current_pose.x:.2f}, {controller.current_pose.y:.2f})")
        controller.move_to_target()

    except rospy.ROSInterruptException:
        rospy.loginfo("程序中断")
    except Exception as e:
        rospy.logerr(f"异常: {e}")
